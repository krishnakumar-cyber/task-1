# pythondev-task1

### Python File Handling and Automation Demo

A small script demonstrating core Python file-handling and automation concepts.

## What it does

1. **Reading & Writing Files** — creates and reads a `.txt` file and a `.csv` file
2. **Automation** — renames/moves a file with `shutil.move()` and deletes a file with `os.remove()`
3. **Exception Handling** — wraps every file operation in `try / except / finally` blocks (`FileNotFoundError`, `PermissionError`, generic `Exception`)

## How to run

```bash
python code.py
```

## Sample Output

```
Created directory: ./file_demo
Sample files created successfully.

--- Reading File ---
Content read: Hello, this is a sample text file for automation demo.

--- Automating File Operations ---
Moved and renamed './file_demo/sample.txt' to './file_demo/archived_sample.txt'

--- Reading CSV Data ---
Processing: Task_A - Completed
Processing: Task_B - Pending

--- Deleting File ---
Deleted './file_demo/archived_sample.txt'

File operation sequence completed.

Current files in ./file_demo:
['data.csv']
```

## Requirements

- Python 3.x — uses only standard library modules (`os`, `shutil`, `csv`), no installs needed
