"""
Task 1 - Python File Handling and Automation
Demonstrates:
    1. Reading and Writing Files (TXT/CSV)
    2. Automation (Rename / Move / Delete)
    3. Exception Handling
"""

import os
import shutil
import csv

# Paths used throughout the demo
BASE_DIR = "./file_demo"
INPUT_FILE = os.path.join(BASE_DIR, "sample.txt")
CSV_FILE = os.path.join(BASE_DIR, "data.csv")
MOVED_FILE = os.path.join(BASE_DIR, "archived_sample.txt")


def setup_demo():
    """Creates a directory and sample files for the automation demo."""
    try:
        if not os.path.exists(BASE_DIR):
            os.makedirs(BASE_DIR)
            print(f"Created directory: {BASE_DIR}")

        # 1. Writing to a text file
        with open(INPUT_FILE, "w") as f:
            f.write("Hello, this is a sample text file for automation demo.")

        # 2. Writing to a CSV file
        with open(CSV_FILE, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["ID", "Name", "Status"])
            writer.writerow([1, "Task_A", "Completed"])
            writer.writerow([2, "Task_B", "Pending"])

        print("Sample files created successfully.")
    except Exception as e:
        print(f"Error during setup: {e}")


def automate_files():
    """Demonstrates reading, renaming/moving, and deleting files with error handling."""
    try:
        # 3. Reading the text file
        print("\n--- Reading File ---")
        with open(INPUT_FILE, "r") as f:
            content = f.read()
            print(f"Content read: {content}")

        # 4. Renaming / Moving a file (Automation)
        print("\n--- Automating File Operations ---")
        if os.path.exists(INPUT_FILE):
            shutil.move(INPUT_FILE, MOVED_FILE)
            print(f"Moved and renamed '{INPUT_FILE}' to '{MOVED_FILE}'")

        # 5. Reading from the CSV file
        print("\n--- Reading CSV Data ---")
        with open(CSV_FILE, "r") as f:
            reader = csv.DictReader(f)
            for row in reader:
                print(f"Processing: {row['Name']} - {row['Status']}")

        # 6. Deleting a file (Automation)
        print("\n--- Deleting File ---")
        if os.path.exists(MOVED_FILE):
            os.remove(MOVED_FILE)
            print(f"Deleted '{MOVED_FILE}'")

    except FileNotFoundError:
        print("Error: The requested file was not found.")
    except PermissionError:
        print("Error: You do not have permission to access these files.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        print("\nFile operation sequence completed.")


if __name__ == "__main__":
    setup_demo()
    automate_files()

    # Verification: list remaining files in the demo directory
    if os.path.exists(BASE_DIR):
        print(f"\nCurrent files in {BASE_DIR}:")
        print(os.listdir(BASE_DIR))
